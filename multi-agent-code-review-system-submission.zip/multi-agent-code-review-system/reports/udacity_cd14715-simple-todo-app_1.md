# 🔍 Code Review Report

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 0/100 |
| **Files Reviewed** | 0 |
| **Critical Issues** | 0 |
| **High Priority Tests** | 0 |
| **Refactoring Opportunities** | 0 |

## 🎯 Top Recommendations

1. 🚨 **Access Restrictions**: Unable to fetch PR metadata and changed files from GitHub. The PR review could not be completed due to permission restrictions on GitHub CLI authentication and web fetch tools. Required: gh pr view commands or GitHub API access to retrieve PR details, patch content, and file paths for analysis.
   - Files: 

## 📁 File Details



---

*Generated at 2026-11-18T00:00:00Z • Duration: 25581ms*
