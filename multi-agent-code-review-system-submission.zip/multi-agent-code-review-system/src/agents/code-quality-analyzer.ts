import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts/code-quality-analyzer.prompt.js';
export const codeQualityAnalyzer: AgentDefinition = {
  description: 'Analyzes changed code for security, correctness, performance, maintainability and best-practice issues with file paths and line numbers.',
  prompt: CODE_QUALITY_ANALYZER_PROMPT,
  model: 'inherit',
  tools: ['Read', 'Glob', 'Grep', 'Skill'],
};
