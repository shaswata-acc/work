import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { TEST_COVERAGE_ANALYZER_PROMPT } from '../prompts/test-coverage-analyzer.prompt.js';
export const testCoverageAnalyzer: AgentDefinition = {
  description: 'Finds untested functions, branches and edge cases, maps existing tests, estimates coverage and proposes concrete assertions.',
  prompt: TEST_COVERAGE_ANALYZER_PROMPT,
  model: 'inherit',
  tools: ['Read', 'Glob', 'Grep', 'Skill'],
};
