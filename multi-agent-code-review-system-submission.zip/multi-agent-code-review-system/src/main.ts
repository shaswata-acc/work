import * as dotenv from 'dotenv';
import { mkdir,writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator,formatError } from './utils/index.js';
dotenv.config();
async function main():Promise<void>{
  const [owner,repo,prText,...extra]=process.argv.slice(2);
  if(!owner||!repo||!prText||extra.length||!/^[1-9]\d*$/.test(prText)){
    console.error('Usage: npm run dev -- <owner> <repo> <positive-pr-number>');process.exitCode=2;return;}
  const pr=Number(prText);if(!Number.isSafeInteger(pr)){console.error('PR number is invalid.');process.exitCode=2;return;}
  const anthropic=Boolean(process.env.ANTHROPIC_API_KEY);
  const aws=Boolean(process.env.AWS_ACCESS_KEY_ID&&process.env.AWS_SECRET_ACCESS_KEY);
  if(!anthropic&&!aws){console.error('Set ANTHROPIC_API_KEY or AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY.');process.exitCode=2;return;}
  if(!anthropic&&aws&&!process.env.AWS_REGION){console.error('AWS_REGION is required for Bedrock.');process.exitCode=2;return;}
  console.log(!anthropic&&aws?'Using AWS Bedrock authentication':'Using Anthropic API authentication');
  if(!process.env.ANTHROPIC_MODEL){console.error('ANTHROPIC_MODEL is required.');process.exitCode=2;return;}
  if(!process.env.PROJECT_ROOT){console.error('PROJECT_ROOT is required.');process.exitCode=2;return;}
  try{
    const result=await new CodeReviewOrchestrator().reviewPullRequest(owner,repo,pr);
    const generator=new ReportGenerator();const dir=join(process.env.PROJECT_ROOT,'reports');
    await mkdir(dir,{recursive:true});const base=`${owner}_${repo}_${pr}`;
    const files:[string,string][]=[
      ['json',generator.generateJSONReport(result)],
      ['md',generator.generateMarkdownReport(result)],
      ['html',generator.generateHTMLReport(result)]];
    for(const [ext,body] of files){const file=join(dir,`${base}.${ext}`);await writeFile(file,body,'utf8');console.log(`Saved ${file}`);}
  }catch(error){console.error(`Review failed: ${formatError(error)}`);process.exitCode=1;}
}
main().catch(e=>{console.error(formatError(e));process.exitCode=1;});
