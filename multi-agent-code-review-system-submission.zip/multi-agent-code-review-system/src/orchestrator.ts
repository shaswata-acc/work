import { query } from '@anthropic-ai/claude-agent-sdk';
import { zodToJsonSchema } from 'zod-to-json-schema';
import { mcpServersConfig } from './config/mcp.config.js';
import { codeQualityAnalyzer, testCoverageAnalyzer, refactoringSuggester } from './agents/index.js';
import { buildOrchestratorPrompt } from './prompts/index.js';
import { ReviewReportSchema, type ReviewReport } from './types/report-types.js';
import { withRetry, withTimeout, ReviewError, ErrorCodes } from './utils/error-handler.js';

export interface OrchestratorOptions {model?:string;maxTurns?:number;timeoutMs?:number;}
export class CodeReviewOrchestrator{
  private model:string;private maxTurns:number;private timeoutMs:number;
  constructor(options:OrchestratorOptions={}){
    this.model=options.model??process.env.ANTHROPIC_MODEL??'';
    this.maxTurns=options.maxTurns??40;this.timeoutMs=options.timeoutMs??600000;
    if(!this.model)throw new ReviewError('ANTHROPIC_MODEL is required.',ErrorCodes.INVALID_CONFIG);
  }
  async reviewPullRequest(owner:string,repo:string,prNumber:number):Promise<ReviewReport>{
    if(!owner||!repo||!Number.isInteger(prNumber)||prNumber<1)
      throw new ReviewError('Valid owner, repo and positive PR number required.',ErrorCodes.INVALID_CONFIG);
    const started=Date.now();
    const schema=zodToJsonSchema(ReviewReportSchema as any,{$refStrategy:'root'}) as Record<string,unknown>;
    return withRetry(()=>withTimeout(async()=>{
      let output:unknown;
      const prompt=buildOrchestratorPrompt(owner,repo,prNumber);
      const options={
        agents:{'code-quality-analyzer':codeQualityAnalyzer,'test-coverage-analyzer':testCoverageAnalyzer,
          'refactoring-suggester':refactoringSuggester},
        allowedTools:['Task','Read','Glob','Grep','Skill', 'mcp__github__*', 'mcp__eslint__*'],
        outputFormat:{type:'json_schema' as const,schema},
      };
      for await(const message of query({prompt,options})){
        if(message.type==='result'&&'structured_output' in message)output=message.structured_output;
        if(message.type==='result'&&message.subtype!=='success')
          throw new ReviewError(`Agent query failed: ${message.subtype}`,ErrorCodes.AGENT_FAILED);
      }
      const parsed=ReviewReportSchema.safeParse(output);
      if(!parsed.success)throw new ReviewError('Invalid structured ReviewReport output.',
        ErrorCodes.VALIDATION_FAILED,{issues:parsed.error.issues});
      return {...parsed.data,metadata:{...parsed.data.metadata,duration:Date.now()-started}};
    },this.timeoutMs,'Pull request analysis timed out'),2,1200);
  }
}
