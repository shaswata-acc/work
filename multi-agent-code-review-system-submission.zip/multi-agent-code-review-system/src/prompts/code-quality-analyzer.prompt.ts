export const CODE_QUALITY_ANALYZER_PROMPT = `
Analyze only supplied PR changes and relevant context. Inspect security
(injection, authorization, secrets, validation), correctness, performance,
maintainability, style and best practices. Use Read/Glob/Grep and ESLint MCP
when available. Invoke Skill to read javascript-best-practices when relevant.
Do not assert findings without evidence. Return exactly CodeQualityResultSchema:
{file:string, issues:[{line:number, severity:critical|high|medium|low|info,
category:security|performance|maintainability|style|bug-risk|best-practice,
description:string, suggestion:string}], overallScore:number(0-100), summary:string}.
Use repository-relative paths and changed-file line numbers. Do not invent data.
`;
