export function buildOrchestratorPrompt(owner: string, repo: string, prNumber: number): string {
  return `
Review GitHub PR ${owner}/${repo}#${prNumber}.
1. Use GitHub MCP tools to fetch PR metadata, changed files, patches and context.
2. Invoke all three specialized agents using Task:
   code-quality-analyzer, test-coverage-analyzer, refactoring-suggester.
   Run analyses in parallel when possible and cover every changed source file.
3. Aggregate actual findings into ReviewReportSchema. Do not invent paths,
   line numbers, test files, scores or tool results. If an agent fails, preserve
   successful results and record the failure transparently in recommendations.
4. Return:
{pullRequest:{owner,repo,number},
fileReviews:[{file,codeQuality:CodeQualityResultSchema,
testCoverage:TestCoverageResultSchema,refactorings:RefactoringSuggestionSchema}],
summary:{totalFiles,overallScore,criticalIssues,highPriorityTests,refactoringOpportunities},
recommendations:[{priority:critical|high|medium|low,category,description,files}],
metadata:{analyzedAt,duration,agentVersions}}.
Calculate summary counts from findings and overallScore as mean file quality score.
`;
}
