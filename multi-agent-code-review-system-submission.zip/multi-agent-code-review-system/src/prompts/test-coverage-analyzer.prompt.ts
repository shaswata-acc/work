export const TEST_COVERAGE_ANALYZER_PROMPT = `
Compare changed source files with existing tests. Identify untested functions,
classes, branches, error paths and edge cases. Estimate coverage only from
inspection; never claim measured runtime coverage unless a coverage tool ran.
Use Read/Glob/Grep and invoke javascript-best-practices via Skill when useful.
Return exactly TestCoverageResultSchema:
{file:string, hasTests:boolean, testFiles:string[], untestedPaths:[{
type:function|class|branch|edge-case, location:string,
priority:critical|high|medium|low, reasoning:string, suggestedTest:string}],
coverageEstimate:number(0-100), summary:string}.
Suggestions must state setup/action and meaningful expected assertions. Do not
invent test files or exact measured coverage.
`;
