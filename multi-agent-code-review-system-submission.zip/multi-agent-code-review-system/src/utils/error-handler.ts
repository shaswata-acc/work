export class ReviewError extends Error {
  constructor(message: string, public code: string, public metadata?: Record<string, unknown>) {
    super(message); this.name = 'ReviewError'; Error.captureStackTrace?.(this, ReviewError);
  }
}
export const ErrorCodes = {
  MISSING_API_KEY:'MISSING_API_KEY', MISSING_GITHUB_TOKEN:'MISSING_GITHUB_TOKEN',
  INVALID_CONFIG:'INVALID_CONFIG', PR_NOT_FOUND:'PR_NOT_FOUND', FILE_NOT_FOUND:'FILE_NOT_FOUND',
  GITHUB_API_ERROR:'GITHUB_API_ERROR', RATE_LIMITED:'RATE_LIMITED',
  AGENT_TIMEOUT:'AGENT_TIMEOUT', AGENT_FAILED:'AGENT_FAILED',
  STRUCTURED_OUTPUT_FAILED:'STRUCTURED_OUTPUT_FAILED', RETRY_EXHAUSTED:'RETRY_EXHAUSTED',
  VALIDATION_FAILED:'VALIDATION_FAILED', UNKNOWN_ERROR:'UNKNOWN_ERROR',
} as const;
export type ErrorCode = typeof ErrorCodes[keyof typeof ErrorCodes];
const sleep = (ms:number) => new Promise<void>(r => setTimeout(r,ms));
export async function withRetry<T>(fn:()=>Promise<T>, maxRetries=3, delayMs=1000):Promise<T> {
  let last:unknown;
  for(let attempt=0; attempt<=Math.max(0,maxRetries); attempt++){
    try{return await fn();}catch(error){
      last=error;if(attempt>=Math.max(0,maxRetries))break;
      await sleep(delayMs*Math.pow(2,attempt)+Math.random()*100);
    }
  }
  throw new ReviewError(`Retry limit exhausted: ${last instanceof Error?last.message:String(last)}`,
    ErrorCodes.RETRY_EXHAUSTED,{cause:String(last),attempts:Math.max(0,maxRetries)+1});
}
export async function withTimeout<T>(fn:()=>Promise<T>, timeoutMs:number,
  errorMessage='Operation timed out'):Promise<T>{
  let timer:ReturnType<typeof setTimeout>|undefined;
  try{return await Promise.race([fn(),new Promise<never>((_,reject)=>{
    timer=setTimeout(()=>reject(new ReviewError(errorMessage,ErrorCodes.AGENT_TIMEOUT,{timeoutMs})),timeoutMs);
  })]);}finally{if(timer)clearTimeout(timer);}
}
export function isReviewError(e:unknown):e is ReviewError{return e instanceof ReviewError;}
export function formatError(e:unknown):string{return isReviewError(e)?`[${e.code}] ${e.message}`:e instanceof Error?e.message:String(e);}
