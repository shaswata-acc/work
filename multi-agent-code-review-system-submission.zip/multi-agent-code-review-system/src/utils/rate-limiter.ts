export interface RateLimiterConfig {maxRequestsPerMinute:number;maxTokensPerMinute:number;maxConcurrent:number;}
export const DEFAULT_RATE_LIMITS:RateLimiterConfig={maxRequestsPerMinute:50,maxTokensPerMinute:100000,maxConcurrent:5};
interface RequestRecord{timestamp:number;tokens:number;}
const sleep=(ms:number)=>new Promise<void>(r=>setTimeout(r,ms));
export class RateLimiter{
  private config:RateLimiterConfig;
  private requestHistory:RequestRecord[]=[];
  private activeRequests=0;
  private waitQueue:Array<()=>void>=[];
  constructor(config:Partial<RateLimiterConfig>={}){this.config={...DEFAULT_RATE_LIMITS,...config};}
  async acquire(estimatedTokens=1000):Promise<void>{
    const tokens=Math.max(0,Math.floor(estimatedTokens));
    while(this.activeRequests>=this.config.maxConcurrent)await this.waitForSlot();
    await this.waitForRateLimit(tokens);
    while(this.activeRequests>=this.config.maxConcurrent)await this.waitForSlot();
    this.activeRequests++;this.requestHistory.push({timestamp:Date.now(),tokens});
  }
  release(actualTokens?:number):void{
    this.activeRequests=Math.max(0,this.activeRequests-1);
    if(actualTokens!==undefined&&this.requestHistory.length){const latest=this.requestHistory[this.requestHistory.length-1];if(latest)latest.tokens=actualTokens;}
    this.waitQueue.shift()?.();
  }
  getStatus(){this.pruneOldRecords();const requestsInWindow=this.requestHistory.length;
    const tokensInWindow=this.requestHistory.reduce((s,r)=>s+r.tokens,0);
    return{activeRequests:this.activeRequests,requestsInWindow,tokensInWindow,
      availableRequests:Math.max(0,this.config.maxRequestsPerMinute-requestsInWindow),
      availableTokens:Math.max(0,this.config.maxTokensPerMinute-tokensInWindow)};}
  canProceed(estimatedTokens=1000):boolean{
    this.pruneOldRecords();const used=this.requestHistory.reduce((s,r)=>s+r.tokens,0);
    return this.activeRequests<this.config.maxConcurrent&&this.requestHistory.length<this.config.maxRequestsPerMinute
      &&used+estimatedTokens<=this.config.maxTokensPerMinute;
  }
  private async waitForSlot():Promise<void>{await new Promise<void>(resolve=>this.waitQueue.push(resolve));}
  private async waitForRateLimit(estimatedTokens:number):Promise<void>{
    if(estimatedTokens>this.config.maxTokensPerMinute)throw new Error('Request exceeds tokens-per-minute limit.');
    while(true){this.pruneOldRecords();const used=this.requestHistory.reduce((s,r)=>s+r.tokens,0);
      if(this.requestHistory.length<this.config.maxRequestsPerMinute&&used+estimatedTokens<=this.config.maxTokensPerMinute)return;
      const oldest=this.requestHistory[0];if(!oldest)return;
      await sleep(Math.min(5000,Math.max(100,oldest.timestamp+60000-Date.now()+100)));
    }
  }
  private pruneOldRecords():void{const cutoff=Date.now()-60000;this.requestHistory=this.requestHistory.filter(r=>r.timestamp>cutoff);}
}
export async function withRateLimit<T>(limiter:RateLimiter,fn:()=>Promise<T>,tokens=1000):Promise<T>{
  await limiter.acquire(tokens);try{return await fn();}finally{limiter.release();}
}
export const globalRateLimiter=new RateLimiter();
