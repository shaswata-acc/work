import {describe,it,expect} from 'vitest';
import {zodToJsonSchema} from 'zod-to-json-schema';
import {CodeQualityResultSchema,TestCoverageResultSchema,RefactoringSuggestionSchema} from '../src/types/analysis-results.js';
import {ReviewReportSchema} from '../src/types/report-types.js';
const quality={file:'src/a.ts',issues:[],overallScore:100,summary:'Clean'};
const coverage={file:'src/a.ts',hasTests:true,testFiles:['tests/a.test.ts'],untestedPaths:[],coverageEstimate:100,summary:'Covered'};
const refactor={file:'src/a.ts',suggestions:[],summary:'No changes'};
describe('analysis schemas',()=>{
 it('accepts valid quality and empty issues',()=>expect(CodeQualityResultSchema.parse(quality)).toEqual(quality));
 it('rejects invalid quality score and severity',()=>expect(CodeQualityResultSchema.safeParse({...quality,overallScore:101,issues:[{line:1,severity:'urgent',category:'security',description:'x',suggestion:'y'}]}).success).toBe(false));
 it('accepts coverage boundary values',()=>{expect(TestCoverageResultSchema.parse({...coverage,coverageEstimate:0}).coverageEstimate).toBe(0);expect(TestCoverageResultSchema.parse(coverage).coverageEstimate).toBe(100);});
 it('rejects malformed test gaps',()=>expect(TestCoverageResultSchema.safeParse({...coverage,untestedPaths:[{type:'method'}]}).success).toBe(false));
 it('accepts refactoring schema',()=>expect(RefactoringSuggestionSchema.parse(refactor)).toEqual(refactor));
});
describe('ReviewReport schema',()=>{
 const report={pullRequest:{owner:'octocat',repo:'Hello-World',number:1},fileReviews:[{file:'src/a.ts',codeQuality:quality,testCoverage:coverage,refactorings:refactor}],summary:{totalFiles:1,overallScore:100,criticalIssues:0,highPriorityTests:0,refactoringOpportunities:0},recommendations:[],metadata:{analyzedAt:new Date(0).toISOString(),duration:1,agentVersions:{orchestrator:'test'}}};
 it('accepts valid report',()=>expect(ReviewReportSchema.parse(report).pullRequest.number).toBe(1));
 it('rejects missing required fields',()=>expect(ReviewReportSchema.safeParse({pullRequest:report.pullRequest}).success).toBe(false));
 it('exports JSON schema',()=>expect(zodToJsonSchema(ReviewReportSchema,{$refStrategy:'root'})).toBeTruthy());
});
